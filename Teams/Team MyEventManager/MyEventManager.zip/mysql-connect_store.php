<?php
// good example can be found here: https://www.cloudways.com/blog/custom-php-mysql-contact-form/
$servername = "134.119.225.132:3304";
$username = "db277477_1066";
$password = "WWI22018";
$dbname = "db277477_1066";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
else {
    echo "Connected successfully";
    echo "<br>";
    $titel = $conn->real_escape_string($_POST["titel_st"]);
    $adresse = $conn->real_escape_string($_POST["adres"]);
    $oeffnungszeiten_day1 = $conn->real_escape_string($_POST["day1"]);
    $oeffnungszeiten_day2 = $conn->real_escape_string($_POST["day2"]);
    $oeffnungszeiten_time1 = $conn->real_escape_string($_POST["time1"]);
    $oeffnungszeiten_time2 = $conn->real_escape_string($_POST["time2"]);
    $oeffnungszeiten_day3 = $conn->real_escape_string($_POST["day3"]);
    $oeffnungszeiten_day4 = $conn->real_escape_string($_POST["day4"]);
    $oeffnungszeiten_time3 = $conn->real_escape_string($_POST["time3"]);
    $oeffnungszeiten_time4 = $conn->real_escape_string($_POST["time4"]);
    $beschreibung = $conn->real_escape_string($_POST["beschreib"]);
 
    $sql = "INSERT INTO User (Adresse, Beschreibung, OEF_Day1, OEF_Day2, OEF_Time1, OEF_Time2, OEF_Day3, OEF_Day4, OEF_Time3, OEF_Time4, Titel)
    VALUES ('$adresse', '$beschreibung', '$oeffnungszeiten_day1', '$oeffnungszeiten_day2', '$oeffnungszeiten_time1', '$oeffnungszeiten_time2','$oeffnungszeiten_day3', '$oeffnungszeiten_day4', '$oeffnungszeiten_time3', '$oeffnungszeiten_time4', '$titel')";
    
    echo $sql;
    echo "<br>";
    if ($conn->query($sql) === TRUE) {
        echo "New record created successfully";
        echo "<br>";
        echo "Entries written:";
        echo $titel;
        echo "<br>";
        echo $adresse;
        echo "<br>";
        echo $oeffnungszeiten_day1;
        echo "<br>";
        echo $oeffnungszeiten_day2;
        echo "<br>";
        echo $oeffnungszeiten_time1;
        echo "<br>";
        echo $oeffnungszeiten_time2;
        echo "<br>";
        echo $oeffnungszeiten_day3;
        echo "<br>";
        echo $oeffnungszeiten_day4;
        echo "<br>";
        echo $oeffnungszeiten_time3;
        echo "<br>";
        echo $oeffnungszeiten_time4;
        echo "<br>";
        echo $beschreibung;
        echo "<br>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
    
    $conn->close();    
}
// MySQL Database settings
//  titel	            varchar(256)	utf8_bin	Nein
//	adresse	            varchar(256)	utf8_bin	Nein			
//	oeffnungszeiten*x   varchar(256)	utf8_bin	Nein			
//	beschreibung	    varchar(256)	utf8_bin	Nein	
//	Bilder      	    Bilddatei      	utf8_bin	Nein			
?>