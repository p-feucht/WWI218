<?php
// good example can be found here: https://www.cloudways.com/blog/custom-php-mysql-contact-form/
$servername = "134.119.225.132:3304";
$username = "db277477_1066";
$password = "WWI22018";
$dbname = "db277477_1066";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
else {
    echo "Connected successfully";
    echo "<br>";
    $titel = $conn->real_escape_string($_POST["titel_ev"]);
    $store = $conn->real_escape_string($_POST["store"]);
    $datum = $conn->real_escape_string($_POST["datum"]);
    $eventbeginn = $conn->real_escape_string($_POST["ev_begin"]);
    $eventende = $conn->real_escape_string($_POST["ev_end"]);
    $beschreibung = $conn->real_escape_string($_POST["beschreib_ev"]);
 
    $sql = "INSERT INTO User (Titel, Store, Datum, Time_Begin, Time_End, Beschreibung)
    VALUES ('$titel', '$store', '$datum', '$eventbeginn', '$eventende', '$beschreibung')";
    
    echo $sql;
    echo "<br>";
    
    if ($conn->query($sql) === TRUE) {
        echo "New record created successfully";
        echo "<br>";
        echo "Entries written:";
        echo $titel;
        echo "<br>";
        echo $store;
        echo "<br>";
        echo $datum;
        echo "<br>";
        echo $eventbeginn;
        echo "<br>";
        echo $eventende;
        echo "<br>";
        echo $beschreibung;
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
    
    $conn->close();    
}
// MySQL Database settings
// Event ID
//  Titel	            varchar(256)	utf8_bin	Nein
//	Store	            varchar(256)	utf8_bin	Nein			
//	Datum	            varchar(256)	utf8_bin	Nein			
//	Time_Begin          varchar(256)	utf8_bin	Nein	
//	Time_End	        varchar(256)	utf8_bin	Nein	
//	beschreibung	    varchar(256)	utf8_bin	Nein	
?>