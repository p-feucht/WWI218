<?php
// good example can be found here: https://www.cloudways.com/blog/custom-php-mysql-contact-form/
$servername = "134.119.225.132:3304";
$username = "db277477_1066";
$password = "WWI22018";
$dbname = "db277477_1066";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
else {
    echo "Connected successfully";
    echo "<br>";
    $username = $conn->real_escape_string($_POST["user"]);
    $email = $conn->real_escape_string($_POST["email"]);
    $passwort = $conn->real_escape_string($_POST["pass"]);
    $re_passwort = $conn->real_escape_string($_POST["re_pass"]);
    $unternehmen_name = $conn->real_escape_string($_POST["name_unt"]);
    $kreditkartennummer = $conn->real_escape_string($_POST["kredit_nummer"]);
 
    $sql = "INSERT INTO User (Username, EMail, Passwort, Unternehmen_Name, Kreditkartennummer)
    VALUES ('$username', '$email', PASSWORD('$passwort'), '$unternehmen_name', '$kreditkartennummer')";
    
    echo $sql;
    echo "<br>";
    if ($conn->query($sql) === TRUE) {
        echo "New record created successfully";
        echo "<br>";
        echo "Entries written:";
        echo $username;
        echo "<br>";
        echo $email;
        echo "<br>";
        echo $passwort;
        echo "<br>";
        echo $re_passwort;
        echo "<br>";
        echo $unternehmen_name;
        echo "<br>";
        echo $kreditkartennummer;
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
    
    $conn->close();    
}
// MySQL Database settings
//  username	            char(20)	    utf8_bin	Nein
//	email	                char(40)	    utf8_bin	Nein			
//	passwort	            char(40)	    utf8_bin	Nein			
//	unternehmen_name	    char(30)	    utf8_bin	Nein	
//	kreditkartennummer	    int(30)      	utf8_bin	Nein			
?>