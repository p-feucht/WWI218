<?php
// good example can be found here: https://www.cloudways.com/blog/custom-php-mysql-contact-form/
$servername = "134.119.225.132:3304";
$username = "db277477_1066";
$password = "WWI22018";
$dbname = "db277477_1066";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
        mysql_select_db(eventmanager) or die(mysql_error());

        $sql = "SELECT * FROM 'Event'";
        $query = mysql_query($sql);
        
        while($row = mysql_fetch_assoc($query)){
            echo htmlspecialchars_decode(stripslashes($row['details'])); //The details is what contains the <strong>Test</strong>
        }
    
    $conn->close();    
}
// MySQL Database settings
// Event ID
//  Titel	            varchar(256)	utf8_bin	Nein
//	Store	            varchar(256)	utf8_bin	Nein			
//	Datum	            varchar(256)	utf8_bin	Nein			
//	Time_Begin          varchar(256)	utf8_bin	Nein	
//	Time_End	        varchar(256)	utf8_bin	Nein	
//	beschreibung	    varchar(256)	utf8_bin	Nein	
?>